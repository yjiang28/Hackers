// Credentials

var URL = 'wss://ws.dev.nuance.com/?';

var APP_ID = "NMDPTRIAL_yzha885_uwo_ca20170129012845";
var APP_KEY = "57179411a798127998045016ae9a0d5c30354fbed8e575996950dc367de863d4fff7e5a78ff82028fc703eaa0b4b063b8156f9593b6ef3a5becfdb3cb73f10b6";
var USER_ID = "";
var NLU_TAG = "M5081_A2361";

// ASR
// See: https://developer.nuance.com/public/index.php?task=supportedLanguages
var ASR_LANGUAGE = "eng-USA";

// TTS
// See: https://developer.nuance.com/public/index.php?task=supportedLanguages
var TTS_LANGUAGE = "fra-FRA";
var TTS_VOICE = "";
