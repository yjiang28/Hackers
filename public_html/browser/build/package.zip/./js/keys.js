// keys.js
// Contains keys to run this demo
// The keys should be kept secret and separate from the code
// Enter your keys below to take the first in running this step 
// VROOOOM VROOM

// Returns an object with the required credentials
function getKeys () {
	return {
		CLARIFAI_CLIENT_ID: "jC6GRWmkx85P_lyVyEu1t0GP9EEEKYEbw6by7IRN",
		CLARIFAI_CLIENT_SECRET: "x9CN4t3rnzXdFcSTqjaIQkYnLv5r4uYvcTaNQCI2"
	}
}